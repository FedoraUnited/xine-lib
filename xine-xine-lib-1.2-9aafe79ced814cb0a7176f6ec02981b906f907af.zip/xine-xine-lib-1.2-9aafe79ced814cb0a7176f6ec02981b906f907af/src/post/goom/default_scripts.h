#ifndef _DEFAULT_SCRIPTS_H
#define _DEFAULT_SCRIPTS_H

#define GOOM_MAIN_SCRIPT ""

#endif
